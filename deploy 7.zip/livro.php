<?php
    class Livro {
    public $id;
    public $imagemCapa;
    public $titulo;
    public $pdf;
	public $idgenero;
    
    public function __construct($id, $imagemCapa, $titulo, $pdf, $idgenero){
        $this->id = $id;
        $this->imagemCapa = $imagemCapa;
        $this->titulo = $titulo;
        $this->pdf = $pdf;
		$this->genero= $idgenero;
    }

    
   public static function all() {

        try {

            $list = [];
            $db = Db::getInstance();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $req = $db->prepare('SELECT * FROM tblLivro');
            $req->execute();

            // resultados do banco
            foreach($req->fetchAll() as $item) {
                $list[] = new Livro
                    ($item['id'], 
                     $item['capa'], 
                     $item['titulo'],
                     $item['pdf'],
					 $item['idgenero']
                    );
            }

            return $list;
        } catch (PDOExc\zauueption $e) {
            echo 'Connection failed: '.$e->getMessage();
        }
    }
        
        
    public static function buscar($query) {

        try {

            $list = [];
            $db = Db::getInstance();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = "SELECT * FROM tblLivro where titulo like '%". $query ."%';";
            $req = $db->prepare($sql);
            $req->execute();
            
          

            // resultados do banco
            foreach($req->fetchAll() as $item) {
                $list[] = new Livro
                    ($item['id'], 
                     $item['capa'], 
                     $item['titulo'],
                     $item['pdf'],
					 $item['idgenero']
                    );
            }

            return $list;
        } catch (PDOExc\zauueption $e) {
            echo 'Connection failed: '.$e->getMessage();
        }
    }
}
?>