<?php
	mysql_connect('localhost', 'root', 'bcd127');
	mysql_select_db('dbellreader');
	
	$usuario = $_GET['usuario'];
	$senha = $_GET['senha'];
	
	$sql = "select * from tbllogin where usuario='".$usuario."' and senha=".$senha;
	$select = mysql_query($sql);
	
	if($rs = mysql_fetch_array($select)){
		echo json_encode($rs);
	}else{
		('invalido');
	}
	

?>