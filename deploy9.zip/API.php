<?php
require_once('conexao.php');
require_once('livro.php');


$listaLivros = Livro::all();
echo json_encode($listaLivros);
	

?>