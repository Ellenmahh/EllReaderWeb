<?php
	$conexao = new mysqli('localhost', 'root', 'bcd127','dbellreader');
	
	
	$id_livro = $_GET['id'];
	
	$sql = "select * from tbllivro where id=".$id_livro;
	$select = mysqli_query($conexao,$sql);
	
	while($rs = mysqli_fetch_array($select)){
		$favoritos = $rs['favoritos'];
        if($favoritos == 0){
            $sql="UPDATE tbllivro SET favoritos = 1 where id =".$id_livro;
        }else {
            $sql ="UPDATE tbllivro SET favoritos = 0 where id =".$id_livro;
        }
          
	}
    mysqli_query($conexao,$sql);
	

?>