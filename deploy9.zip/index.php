<?php
//$conexao = new mysqli('localhost', 'root', 'bcd127','dbellreader');
$conexao = new mysqli($_SERVER['RDS_HOSTNAME'],$_SERVER['RDS_USERNAME'],$_SERVER['RDS_PASSWORD'],$_SERVER['RDS_DB_NAME']);

//$conexao = mysqli_connect($_SERVER['RDS_HOSTNAME'],$_SERVER['RDS_USERNAME'],$_SERVER['RDS_PASSWORD']);
//mysqli_select_db($conexao,$_SERVER['RDS_DB_NAME']);


if(isset($_POST['btnsalvar'])){

    $titulo = $_POST['txtTitulo'];
	$slgeneros = $_POST['slgeneros'];

    $capa_arq = basename ($_FILES['fleCapa']['name']);
    // caminho da imagem
    $caminho_img = "capas/";
    //resgatar o nome do arquivo com o caminho e o nome do objeto
    $nome_capa = $caminho_img . $capa_arq;

     $extensao = strtolower(substr($capa_arq,strlen($capa_arq)-3,3));

    if($extensao == 'jpg' || $extensao == 'png' ){
        // mover a imagem para a pasta arquivo que o caminho da imagem
        move_uploaded_file($_FILES['fleCapa']['tmp_name'],$nome_capa);
    }

    $pdf_arq = basename ($_FILES['flePdf']['name']);
    $caminho_pdf="livros/";
    $nome_pdf = $caminho_pdf . $pdf_arq;
    $extensao = strtolower(substr($pdf_arq,strlen($pdf_arq)-3,3));

    if($extensao == 'pdf' ){

        // mover a imagem para a pasta arquivo que o caminho da imagem
        if(move_uploaded_file($_FILES['flePdf']['tmp_name'],$nome_pdf)){
            $sql = " INSERT INTO tbllivro(capa,titulo,pdf,idgenero) VALUES('".$nome_capa."','".$titulo."','".$nome_pdf."',".$slgeneros.");";
            mysqli_query($conexao,$sql);
            if(mysql_affected) {
                echo  ("<script language=javascript>
                        alert('Enviado com sucesso!!');
                        location.href = 'index.php';
                    </script>");
            }
           //header('location:EllReader.php');
            //echo $sql;
        }

    }
}
	$sql = "select * from tblgenero";
	$selection = mysqli_query($conexao,$sql);

?>

<html>
	<head>
    	<title>Ell Reader</title>
		<link rel="stylesheet" type="text/css" href="css/css.css">
		<meta charset="utf-8">
	</head>
	<body >
	<form name = "frmreader" method="post" enctype="multipart/form-data" action="index.php">
		<section id="principal">
			<div id="conteudo">
					<div class="titulo"><img src="capas/logo.png"></div>
					<div id = "capa"> CAPA:<input type="file" requered name="fleCapa"> </div>
					<div id = "titulo">TÍTULO:<input type="text" requered name="txtTitulo" > </div>
					<div id = "livro">LIVRO EM PDF:<input type="file" requered name="flePdf"></div>
					<div id = "genero">GÊNERO:
						<select name="slgeneros">
							<?php while($lista = mysqli_fetch_array($selection)){ ?>
								<option value = "<?php echo($lista['idgenero'])?>">
									<?php echo($lista['genero'])  ?>
								</option>

							<?php } ?>
						</select>
					</div>
					<div id = "botao"><input type="submit" name="btnsalvar" value="Salvar" text="center" class="botaosalvar"></div>
			</div>
		</section>
	</form>
	<footer id ="rodape">

	</footer>
	</body>
</html>
