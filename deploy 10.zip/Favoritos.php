<?php
    $conexao = new mysqli($_SERVER['RDS_HOSTNAME'],$_SERVER['RDS_USERNAME'],$_SERVER['RDS_PASSWORD'],$_SERVER['RDS_DB_NAME']);
	
	$id_livro = $_GET['id'];
	
	$sql = "select * from tbllivro where favoritos=1";
	$select = mysqli_query($conexao,$sql);
	
	while($rs = mysqli_fetch_array($select)){
		foreach($req->fetchAll() as $item) {
            $list[] = new Livro
                (	$item['id'],
					$item['capa'],
					$item['titulo'],
					$item['pdf'],
					$item['idgenero'],
					$item['favoritos']
				);
        }
	}
	echo json_encode($list);

?>