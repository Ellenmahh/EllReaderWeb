<?php
$conexao = mysql_connect('localhost','root','abcd127');
mysql_select_db('dbellreader');


if(isset($_POST['btnsalvar'])){
   
    $titulo = $_POST['txtTitulo'];
	$slgeneros = $_POST['slgeneros'];
    
    $capa_arq = basename ($_FILES['fleCapa']['name']);
    // caminho da imagem
    $caminho_img = "capas/";
    //resgatar o nome do arquivo com o caminho e o nome do objeto
    $nome_capa = $caminho_img . $capa_arq;
    
     $extensao = strtolower(substr($capa_arq,strlen($capa_arq)-3,3));
    
    if($extensao == 'jpg' || $extensao == 'png' ){
       
        // mover a imagem para a pasta arquivo que o caminho da imagem
        move_uploaded_file($_FILES['fleCapa']['tmp_name'],$nome_capa);     
        
    }
    
    $pdf_arq = basename ($_FILES['flePdf']['name']);
    $caminho_pdf="livros/";
    $nome_pdf = $caminho_pdf . $pdf_arq;
	
    
    $extensao = strtolower(substr($pdf_arq,strlen($pdf_arq)-3,3));
    
    if($extensao == 'pdf' ){
       
        // mover a imagem para a pasta arquivo que o caminho da imagem
        if(move_uploaded_file($_FILES['flePdf']['tmp_name'],$nome_pdf)){
            $sql = " INSERT INTO tblLivro(capa,titulo,pdf,idgenero) VALUES('".$nome_capa."','".$titulo."','".$nome_pdf."',".$slgeneros.");";
            mysql_query($sql);
            if(mysql_affected) {
                echo  ("<script>alert('Email enviado com Sucesso!);</script>");
            }
           //header('location:EllReader.php');
            //echo $sql;
        }     
        
    }
}
	$sql = "select * from tblgenero";
	$selection = mysql_query($sql);
	
?>

<html>
	<head>
    	<title>Ell Reader</title> 
		<link rel="stylesheet" type="text/css" href="css/css.css">
		<meta charset="utf-8">
	</head>
	<body >
	<form name = "frmreader" method="post" enctype="multipart/form-data" action="EllReader.php">
		<section id="principal"> 
			<div id="conteudo">
					<div class="titulo"><img src="capas/logo.png"></div>
					<div id = "capa"> CAPA:<input type="file" requered name="fleCapa"> </div>
					<div id = "titulo">TÍTULO:<input type="text" requered name="txtTitulo" > </div>
					<div id = "livro">LIVRO EM PDF:<input type="file" requered name="flePdf"></div>
					<div id = "genero">GÊNERO:
						<select name="slgeneros">
							<?php while($larigenero = mysql_fetch_array($selection)){ ?>
								<option value = "<?php echo($larigenero['idgenero'])?>"> 
									<?php echo($larigenero['genero'])  ?> 
								</option>
										 
							<?php } ?>
						</select>
					</div>
					<div id = "botao"><input type="submit" name="btnsalvar" value="Salvar" text="center" class="botaosalvar"></div>
			</div>
		</section> 
	</form>
	<footer id ="rodape">

	</footer>
	</body>
</html>