<?php

//$conexao = new mysqli('localhost', 'root', 'abcd127','dbellreader');
$conexao = new mysqli($_SERVER['RDS_HOSTNAME'],$_SERVER['RDS_USERNAME'],$_SERVER['RDS_PASSWORD'],$_SERVER['RDS_DB_NAME']);


	$usuario = $_GET['usuario'];
	$senha = $_GET['senha'];

	$sql = "select * from tbllogin where usuario='".$usuario."' and senha=".$senha;

  $select =mysqli_query($conexao,$sql);

	if($rs = mysqli_fetch_array($select)){
		echo json_encode($rs);
	}else{
	 echo('invalido');
	}


?>
